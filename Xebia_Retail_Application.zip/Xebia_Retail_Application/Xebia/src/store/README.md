Step1 : Execute Retail.java class since main method is defined in this class.
step2: For checking user belongs to employee or affiliate of the store or not please check Employee.java and Affiliate.java class and accordingly you can provide input.
Step3 : Items belongs to grocery or not, please check grocery class for input request
Step4 : Enter the input as per expected

Output:(Executed the test case and got the below result based on input provided)
-------
Case1:If the user is an employee of the store, he gets a 30% discount
--------------------------------------------------------------------
Welcome to Xebia Store
Please Enter the userName
abhishek
Welcome abhishek
Enter the retail item
pen
Enter price per item
10
Enter the quantity
50
User belongs to an Employee so eligible for 30% discount
Item Name : pen
Price per item : 10
Total quantity : 50
Total amount : 500.0
Discount : 150.0
Net amount to pay :  350.0

Case2:If the user is an affiliate of the store, he gets a 10% discount 
----------------------------------------------------------------------
Welcome to Xebia Store
Please Enter the userName
reena
Welcome reena
Enter the retail item
pencil
Enter price per item
5
Enter the quantity
200
User belongs to an affiliate so eligible for 10% discount
Item Name : pencil
Price per item : 5
Total quantity : 200
Total amount : 1000.0
Discount : 100.0
Net amount to pay :  900.0


Case3:If the user has been a customer for over 2 years, he gets a 5% discount
-----------------------------------------------------------------------------
Welcome to Xebia Store
Please Enter the userName
priyanka
Welcome priyanka
Enter the retail item
book
Enter price per item
30
Enter the quantity
7
How old the user is
5
User is more then 2 years old so eligible for 5% discount
Item Name : book
Price per item : 30
Total quantity : 7
Total amount : 210.0
Discount : 10.5
Net amount to pay :  199.5


Case4:For every $100 on the bill, there would be a $ 5 discount (e.g. for $ 990, you get $ 45 as a discount). 
--------------------------------------------------------------------------------------
Welcome to Xebia Store
Please Enter the userName
ajit
Welcome ajit
Enter the retail item
shirt
Enter price per item
99
Enter the quantity
10
How old the user is
1
Total amount is more then 100$ so eligible for 5$ discount per 100$
Item Name : shirt
Price per item : 99
Total quantity : 10
Total amount : 990.0
Discount : 45.0
Net amount to pay :  945.0


Case5:The percentage based discounts do not apply on groceries.
---------------------------------------------------------------
Welcome to Xebia Store
Please Enter the userName
manoj
Welcome manoj
Enter the retail item
rice
Enter price per item
40
Enter the quantity
10
No discount on Groceries items
Item Name : rice
Price per item : 40
Total quantity : 10
Total amount : 400.0
Discount : 0.0
Net amount to pay :  400.0


Case6:A user can get only one of the percentage based discounts on a bill. 
---------------------------------------------------------------------------
Welcome to Xebia Store
Please Enter the userName
preeti
Welcome preeti
Enter the retail item
top
Enter price per item
450
Enter the quantity
5
User belongs to an Employee so eligible for 30% discount
Item Name : top
Price per item : 450
Total quantity : 5
Total amount : 2250.0
Discount : 675.0
Net amount to pay :  1575.0

Case7:For less then $100 on the bill, there is no discount. 
---------------------------------------------------------------------------
Welcome to Xebia Store
Please Enter the userName
geeta
Welcome geeta
Enter the retail item
pen
Enter price per item
5
Enter the quantity
10
How old the user is
1
Total amount is less then 100$ so not eligible for any discount
Item Name : pen
Price per item : 5
Total quantity : 10
Total amount : 50.0
Discount : 0.0
Net amount to pay :  50.0


