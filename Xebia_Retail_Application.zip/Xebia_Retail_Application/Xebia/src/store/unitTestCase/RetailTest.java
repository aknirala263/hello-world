package store.unitTestCase;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import store.Discount;
import store.Discount;

/**
 * @author Nirala
 * unit test case for different scenario
 *
 */
public class RetailTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("Welcome to Xebia Store");
	}

	@Test
	//user belongs to an Employee having 30% discount
	public void testNetAmountEmployee() {
		System.out
				.println("User belongs to an Employee so eligible for 30% discount");
		Discount dis = new Discount();
		String userName = "abhishek";
		String itemName = "pen";
		int itemRate = 10;
		int noItems = 50;
		int noYears = 5;
		double actualValue = dis.calculateDiscount(userName, itemName,
				itemRate, noItems, noYears);
		Object expectedValue = 350.0;
		assertEquals(expectedValue, actualValue);
	}

	
	@Test
	//User belongs to an affiliate so eligible for 10% discount
	public void testNetAmountAffiliate() {
		System.out
				.println("User belongs to an affiliate so eligible for 10% discount");
		Discount dis = new Discount();
		String userName = "reena";
		String itemName = "pen";
		int itemRate = 20;
		int noItems = 50;
		int noYears = 3;
		double actualValue = dis.calculateDiscount(userName, itemName,
				itemRate, noItems, noYears);
		Object expectedValue = 900.0;
		assertEquals(expectedValue, actualValue);
	}

	@Test
	//if user not belongs to an affiliate or employee and they belongs to more then 2 years
	public void testNetAmountTwoYears() {
		System.out
				.println("User is more then 2 years old so eligible for 5% discount");

		Discount dis = new Discount();
		String userName = "priyanka";
		String itemName = "book";
		int itemRate = 30;
		int noItems = 7;
		int noYears = 3;
		double actualValue = dis.calculateDiscount(userName, itemName,
				itemRate, noItems, noYears);
		Object expectedValue = 199.5;
		assertEquals(expectedValue, actualValue);
	}

	@Test
	//Item contains groceries having no discount
	public void testNetAmountGroceries() {
		System.out.println("No discount on Groceries items");
		Discount dis = new Discount();
		String userName = "manoj";
		String itemName = "rice";
		int itemRate = 40;
		int noItems = 10;
		int noYears = 7;
		double actualValue = dis.calculateDiscount(userName, itemName,
				itemRate, noItems, noYears);
		Object expectedValue = 400.0;
		assertEquals(expectedValue, actualValue);
	}

	@Test
	//Total amount is more then 100$ so eligible for 5$ discount per 100$
	public void testNetAmountMore100$() {
		System.out
				.println("Total amount is more then 100$ so eligible for 5$ discount per 100$");

		Discount dis = new Discount();
		String userName = "ajit";
		String itemName = "shirt";
		int itemRate = 99;
		int noItems = 10;
		int noYears = 1;
		double actualValue = dis.calculateDiscount(userName, itemName,
				itemRate, noItems, noYears);
		Object expectedValue = 945.0;
		assertEquals(expectedValue, actualValue);
	}

	@Test
	//Total amount is less then 100$ so not eligible for any discount
	public void testNetAmountLess100$() {
		System.out
				.println("Total amount is less then 100$ so not eligible for any discount");

		Discount dis = new Discount();
		String userName = "geeta";
		String itemName = "pen";
		int itemRate = 5;
		int noItems = 10;
		int noYears = 1;
		double actualValue = dis.calculateDiscount(userName, itemName,
				itemRate, noItems, noYears);
		Object expectedValue = 50.0;
		assertEquals(expectedValue, actualValue);
	}

	@Test
	//Only one discount applicable
	public void testNetAmountSingleDiscount() {
		System.out
				.println("Only one discount applicable");

		Discount dis = new Discount();
		String userName = "geeta";
		String itemName = "pen";
		int itemRate = 50;
		int noItems = 10;
		int noYears = 5;
		double actualValue = dis.calculateDiscount(userName, itemName,
				itemRate, noItems, noYears);
		Object expectedValue = 475.0;
		assertEquals(expectedValue, actualValue);
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("Thank you for Visiting");
	}
}
