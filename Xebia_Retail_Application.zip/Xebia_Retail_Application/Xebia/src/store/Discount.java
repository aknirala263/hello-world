package store;

import java.util.List;
import java.util.Scanner;

public class Discount {
	/**
	 * @param userName
	 * @param itemName
	 * @param itemRate
	 * @param noItems
	 * @param noYears
	 * @return amountToPay
	 */
	public double calculateDiscount(String userName, String itemName,
			int itemRate, int noItems, int noYears) {
		double netAmount = 0;
		try {
			List<String> groceries = new Grocery().groceriesList();
			ItemDetails itmDisplay = new ItemDetails();
			// if item contains groceries then no discount available
			if (groceries.contains(itemName)) {
				double totalAmount = itemRate * noItems;
				System.out.println("No discount on Groceries items");
				itmDisplay.displayResult(itemName, itemRate, noItems,
						totalAmount, 0, totalAmount);
				return totalAmount;
			} else {
				// calculate final amount after having discount
				double amountToPay = calculateDiscountBasedOnUser(userName,
						itemName, itemRate, noItems, noYears);
				return amountToPay;

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return netAmount;

	}

	/**
	 * @param userName
	 * @param itemName
	 * @param itemRate
	 * @param noItems
	 * @param noYears
	 * @return finalAmountToPay calculate discount based on user and items
	 */
	public double calculateDiscountBasedOnUser(String userName,
			String itemName, int itemRate, int noItems, int noYears) {

		List<String> employee = new Employee().getUser();
		List<String> affiliate = new Affiliate().getUser();
		ItemDetails itmDisplay = new ItemDetails();

		if (employee.contains(userName)) {
			double totalAmount = itemRate * noItems;
			double discount = 0.3 * totalAmount;
			double amountToPay = totalAmount - discount;
			System.out
					.println("User belongs to an Employee so eligible for 30% discount");
			itmDisplay.displayResult(itemName, itemRate, noItems, totalAmount,
					discount, amountToPay);
			return amountToPay;
		} else if (affiliate.contains(userName)) {
			double totalAmount = itemRate * noItems;
			double discount = 0.1 * totalAmount;
			double amountToPay = totalAmount - discount;
			System.out
					.println("User belongs to an affiliate so eligible for 10% discount");
			itmDisplay.displayResult(itemName, itemRate, noItems, totalAmount,
					discount, amountToPay);
			return amountToPay;
		} else {

			double amountToPay = calculateDiscountExceptUserEmpAndAff(userName,
					itemName, itemRate, noItems, noYears);
			return amountToPay;

		}

	}

	/**
	 * @param userName
	 * @param itemName
	 * @param itemRate
	 * @param noItems
	 * @param noYears
	 * User not belong to employee and affiliate
	 * @return amount to pay after discount
	 */
	public double calculateDiscountExceptUserEmpAndAff(String userName,
			String itemName, int itemRate, int noItems, int noYears) {
		ItemDetails itmDisplay = new ItemDetails();
		if (noYears >= 2) {
			double totalAmount = itemRate * noItems;
			double discount = 0.05 * totalAmount;
			double amountToPay = totalAmount - discount;
			System.out
					.println("User is more then 2 years old so eligible for 5% discount");
			itmDisplay.displayResult(itemName, itemRate, noItems, totalAmount,
					discount, amountToPay);
			return amountToPay;
		} else {
			double totalAmount = itemRate * noItems;
			if (totalAmount >= 100) {
				int roundFigAmount = (int) (totalAmount / 100);
				double discount = 5 * roundFigAmount;
				double amountToPay = totalAmount - discount;
				System.out
						.println("Total amount is more then 100$ so eligible for 5$ discount per 100$");
				itmDisplay.displayResult(itemName, itemRate, noItems,
						totalAmount, discount, amountToPay);
				return amountToPay;
			} else {
				System.out
						.println("Total amount is less then 100$ so not eligible for any discount");
				itmDisplay.displayResult(itemName, itemRate, noItems,
						totalAmount, 0, totalAmount);
				return totalAmount;
			}
		}

	}
}
