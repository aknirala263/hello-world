package store;

public class ItemDetails {
	/**
	 * @param itemName
	 * @param itemRate
	 * @param noItems
	 * @param totalAmount
	 * @param discount
	 * @param amountToPay
	 * printing item details
	 */
	public void displayResult(String itemName, int itemRate,
			int noItems, double totalAmount, double discount, double amountToPay) {
		System.out.println("Item Name : " + itemName);
		System.out.println("Price per item : " + itemRate);
		System.out.println("Total quantity : " + noItems);
		System.out.println("Total amount : " + totalAmount);
		System.out.println("Discount : " + discount);
		System.out.println("Net amount to pay :  " + amountToPay);

	}
}
