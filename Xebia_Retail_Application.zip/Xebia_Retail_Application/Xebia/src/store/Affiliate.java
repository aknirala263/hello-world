package store;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Nirala
 * return list of Affiliate user
 */
public class Affiliate implements User{
	
	//Created list of Affiliate user using hard coded value since application is not connected to database
	@Override
	public List<String> getUser() {
		List<String> affiliate = new ArrayList<String>();
		affiliate.add("rajesh");
		affiliate.add("roshan");
		affiliate.add("reena");
		affiliate.add("daivika");
		affiliate.add("anuj");
		return affiliate;
	}
}
