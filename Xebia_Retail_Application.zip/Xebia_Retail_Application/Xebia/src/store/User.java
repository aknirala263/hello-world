package store;

import java.util.List;

/**
 * @author Nirala
 * return the list of Users
 */
public interface User {

	//return the list of Users
	List<String> getUser();
}
