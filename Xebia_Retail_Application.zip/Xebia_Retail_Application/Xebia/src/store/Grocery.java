package store;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Nirala
 * return list of Grocery items
 */
public class Grocery {
	
	//Created list of Grocery items using hard coded value since application is not connected to database
   List<String> groceriesList(){
		List<String> groceries = new ArrayList<String>();
		groceries.add("rice");
		groceries.add("pulse");
		groceries.add("gram");
		groceries.add("biscuit");
		groceries.add("coke");
		return groceries;
	}
}
