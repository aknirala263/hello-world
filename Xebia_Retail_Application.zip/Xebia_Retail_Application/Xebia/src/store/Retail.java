package store;

import java.util.List;
import java.util.Scanner;

/**
 * @author Nirala
 * Starting classes for the application and main method for executing the application
 */
public class Retail {
	public static void main(String[] args) {
		try {
			System.out.println("Welcome to Xebia Store");
			Scanner sc = new Scanner(System.in);
			System.out.println("Please Enter the userName");
			String userName = sc.nextLine();
			System.out.println("Welcome " + userName);
			retailItemDetails(userName);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * @param userName
	 * Entering the user details and item details
	 */
	public static void retailItemDetails(String userName) {
		try {
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter the retail item");
			String itemName = sc.nextLine();
			System.out.println("Enter price per item");
			int itemRate = Integer.parseInt(sc.nextLine());
			System.out.println("Enter the quantity");
			int noItems = Integer.parseInt(sc.nextLine());
			System.out.println("How old the user is");
			int noYears = Integer.parseInt(sc.nextLine());
			Discount rtl = new Discount();
			rtl.calculateDiscount(userName, itemName, itemRate, noItems, noYears);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
