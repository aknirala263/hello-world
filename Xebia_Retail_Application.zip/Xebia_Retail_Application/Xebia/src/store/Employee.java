package store;
import java.util.*;  
/**
 * @author Nirala
 * return list of Employee user
 */
public class Employee implements User{  
	
	//Created list of Employee user using hard coded value since application is not connected to database
	@Override
	public List<String> getUser() {
		List<String> employee = new ArrayList<String>();
		employee.add("abhishek");
		employee.add("manoj");
		employee.add("aakash");
		employee.add("preeti");
		employee.add("rakesh");
		return employee;
	}
 
}  